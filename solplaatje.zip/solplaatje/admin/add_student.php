<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$page_title = 'Add New Student';
require_once __DIR__ . '/../includes/header.php';
require_role('admin');

// --- BACKEND LOGIC ---
$error_message = '';
$success_message = '';

// --- Get Curriculum Options ---
try {
    $curriculum_options_stmt = $pdo->query("
        SELECT DISTINCT p.programme_id, p.programme_name, pm.year_of_study, pm.semester
        FROM programme_modules pm
        JOIN programmes p ON pm.programme_id = p.programme_id
        ORDER BY p.programme_name, pm.year_of_study, pm.semester
    ");
    $curriculum_options = $curriculum_options_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("<div style='padding: 20px; font-family: Arial, sans-serif; border: 2px solid red; background: #ffebeb;'>
            <h2>Database Error!</h2>
            <p>Could not fetch curriculum options. Please check if the <strong>`programme_modules`</strong> table exists.</p>
            <hr>
            <p><strong>Error details:</strong> " . $e->getMessage() . "</p>
         </div>");
}

// --- Function to generate unique 9-digit student number ---
// --- THIS FUNCTION HAS BEEN UPDATED ---
function generateStudentNumber($pdo) {
    do {
        // 1. Start with the fixed prefix '2025'
        $prefix = '2025';
        // 2. Generate a random 5-digit number
        $randomNumber = str_pad(mt_rand(0, 99999), 5, '0', STR_PAD_LEFT);
        // 3. Combine them to create the full 9-digit number
        $number = $prefix . $randomNumber;
        
        // Check if this number already exists in the database
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE student_id_number = ?");
        $stmt->execute([$number]);
        $exists = $stmt->fetchColumn();
    } while ($exists > 0); // Keep looping until a unique number is found
    return $number;
}
// --- END OF UPDATE ---

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $standardModules = $_POST['modules'] ?? [];
    $additionalModules = $_POST['additional_modules'] ?? [];
    $allSelectedModules = array_unique(array_merge($standardModules, $additionalModules));

    $firstName = trim($_POST['first_name']);
    $lastName = trim($_POST['last_name']);
    list($programmeId, $yearOfStudy, $semester) = explode('-', $_POST['course_semester']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $kinName = trim($_POST['kin_name']);
    $kinContact = trim($_POST['kin_contact']);
    $defaultPassword = 'Password123';

    // ✅ Auto-generate student number and email
    $studentNumber = generateStudentNumber($pdo);
    $email = $studentNumber . "@spu.ac.za";

    $pdo->beginTransaction();
    try {
        $sql1 = "INSERT INTO users (loginid, password, first_name, last_name, role) VALUES (?, ?, ?, ?, 'student')";
        $stmt1 = $pdo->prepare($sql1);
        $stmt1->execute([$studentNumber, $defaultPassword, $firstName, $lastName]);
        $newUserId = $pdo->lastInsertId();

        $sql2 = "INSERT INTO students (student_user_id, student_id_number, programme_id, year_of_study, email, phone_number) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt2 = $pdo->prepare($sql2);
        $stmt2->execute([$newUserId, $studentNumber, $programmeId, $yearOfStudy, $email, $phone]);

        $sql3 = "INSERT INTO student_contacts (student_user_id, home_address, next_of_kin_name, next_of_kin_contact) VALUES (?, ?, ?, ?)";
        $stmt3 = $pdo->prepare($sql3);
        $stmt3->execute([$newUserId, $address, $kinName, $kinContact]);

        if (!empty($allSelectedModules)) {
            $sql4 = "INSERT INTO enrollments (student_user_id, module_id, semester) VALUES (?, ?, ?)";
            $stmt4 = $pdo->prepare($sql4);
            foreach ($allSelectedModules as $moduleId) {
                $stmt4->execute([$newUserId, $moduleId, $semester]);
            }
        }

        $pdo->commit();
        $success_message = "Student successfully registered!<br>Student Number: <strong>$studentNumber</strong><br>Email: <strong>$email</strong>";
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error_message = "Database error during registration: " . $e->getMessage();
    }
}
?>

<!-- The HTML and JavaScript part of the file is exactly the same as before -->
<div class="form-container">
    <h2>Add New Student</h2>
    
    <?php if ($success_message): ?><div class="alert alert-success"><?php echo $success_message; ?></div><?php endif; ?>
    <?php if ($error_message): ?><div class="alert alert-danger"><?php echo $error_message; ?></div><?php endif; ?>

    <form action="add_student.php" method="POST">
        <fieldset>
            <legend>Academic Information</legend>
            <div class="form-row">
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input type="text" id="first_name" name="first_name" required>
                </div>
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input type="text" id="last_name" name="last_name" required>
                </div>
            </div>
        </fieldset>

        <fieldset>
            <legend>Course Enrollment</legend>
            <div class="form-row">
                <div class="form-group">
                    <label for="course_semester">Course and Semester</label>
                    <select id="course_semester" name="course_semester" required>
                        <option value="">-- Select a Course and Semester --</option>
                        <?php foreach ($curriculum_options as $option): ?>
                            <option value="<?php echo e($option['programme_id'] . '-' . $option['year_of_study'] . '-' . $option['semester']); ?>">
                                <?php echo e($option['programme_name'] . ' - Year ' . $option['year_of_study'] . ' Semester ' . $option['semester']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Standard Modules for Semester</label>
                    <div id="modules-container" class="modules-container">
                        <small>-- Please select a course first --</small>
                    </div>
                </div>
            </div>
            <div id="additional-module-search-container">
                <label for="additional-module-search">Add Additional Module (Elective/Other)</label>
                <input type="text" id="additional-module-search" placeholder="Search by module code or name...">
                <ul id="search-results"></ul>
                <ul id="additional-modules-list"></ul>
            </div>
        </fieldset>
        
        <fieldset>
            <legend>Personal Information</legend>
            <div class="form-group">
                <label for="phone">Contact Phone Number</label>
                <input type="tel" id="phone" name="phone">
            </div>
            <div class="form-group">
                <label for="address">Home Address</label>
                <textarea id="address" name="address" rows="3"></textarea>
            </div>
             <div class="form-row">
                <div class="form-group">
                    <label for="kin_name">Next of Kin Name</label>
                    <input type="text" id="kin_name" name="kin_name">
                </div>
                <div class="form-group">
                    <label for="kin_contact">Next of Kin Contact Details</label>
                    <input type="text" id="kin_contact" name="kin_contact">
                </div>
            </div>
        </fieldset>
        
        <button type="submit">Register Student</button>
    </form>
</div>

<script>
// The JavaScript does not need to be changed.
document.addEventListener('DOMContentLoaded', function() {
    const courseSemesterSelect = document.getElementById('course_semester');
    const modulesContainer = document.getElementById('modules-container');
    const searchInput = document.getElementById('additional-module-search');
    const searchResults = document.getElementById('search-results');
    const additionalModulesList = document.getElementById('additional-modules-list');

    courseSemesterSelect.addEventListener('change', function() {
        modulesContainer.innerHTML = '<small>Loading...</small>';
        const selectedValue = this.value;
        if (!selectedValue) {
            modulesContainer.innerHTML = '<small>-- Please select a course first --</small>';
            return;
        }
        const [programmeId, year, semester] = selectedValue.split('-');
        fetch(`get_modules.php?programme_id=${programmeId}&year=${year}&semester=${semester}`)
            .then(response => response.json())
            .then(data => {
                modulesContainer.innerHTML = '';
                if (data.length > 0) {
                    data.forEach(module => {
                        const optionDiv = document.createElement('div');
                        optionDiv.className = 'module-option';
                        const checkbox = document.createElement('input');
                        checkbox.type = 'checkbox';
                        checkbox.name = 'modules[]';
                        checkbox.value = module.module_id;
                        checkbox.id = 'module-' + module.module_id;
                        const label = document.createElement('label');
                        label.htmlFor = 'module-' + module.module_id;
                        label.textContent = `${module.module_code} - ${module.module_name}`;
                        optionDiv.appendChild(checkbox);
                        optionDiv.appendChild(label);
                        modulesContainer.appendChild(optionDiv);
                    });
                } else {
                    modulesContainer.innerHTML = '<small>-- No modules found for this semester --</small>';
                }
            })
            .catch(error => {
                console.error('Error fetching modules:', error);
                modulesContainer.innerHTML = '<small>-- Error loading modules --</small>';
            });
    });
    
    // The search logic does not need to be changed either.
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.trim();
        if (searchTerm.length < 2) {
            searchResults.innerHTML = '';
            return;
        }
        const excludeIds = [];
        document.querySelectorAll('input[name="modules[]"]:checked').forEach(cb => excludeIds.push(cb.value));
        document.querySelectorAll('input[name="additional_modules[]"]').forEach(input => excludeIds.push(input.value));
        const excludeQuery = excludeIds.map(id => `exclude[]=${id}`).join('&');
        fetch(`search_modules.php?term=${searchTerm}&${excludeQuery}`)
            .then(response => response.json())
            .then(data => {
                searchResults.innerHTML = '';
                if (data.length > 0) {
                    data.forEach(module => {
                        const li = document.createElement('li');
                        li.textContent = `${module.module_code} - ${module.module_name}`;
                        li.dataset.moduleId = module.module_id;
                        li.dataset.moduleText = `${module.module_code} - ${module.module_name}`;
                        searchResults.appendChild(li);
                    });
                }
            });
    });

    searchResults.addEventListener('click', function(e) {
        if (e.target.tagName === 'LI') {
            const moduleId = e.target.dataset.moduleId;
            const moduleText = e.target.dataset.moduleText;
            addModuleToList(moduleId, moduleText);
            searchInput.value = '';
            searchResults.innerHTML = '';
        }
    });

    function addModuleToList(id, text) {
        const li = document.createElement('li');
        li.dataset.moduleId = id;
        const textSpan = document.createElement('span');
        textSpan.textContent = text;
        const removeBtn = document.createElement('span');
        removeBtn.textContent = '✖';
        removeBtn.className = 'remove-btn';
        removeBtn.title = 'Remove Module';
        removeBtn.onclick = function() {
            li.remove();
        };
        const hiddenInput = document.createElement('input');
        hiddenInput.type = 'hidden';
        hiddenInput.name = 'additional_modules[]';
        hiddenInput.value = id;
        li.appendChild(textSpan);
        li.appendChild(removeBtn);
        li.appendChild(hiddenInput);
        additionalModulesList.appendChild(li);
    }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>