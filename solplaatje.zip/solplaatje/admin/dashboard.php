<?php
// Start the session right at the beginning to guarantee it's ready.
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$page_title = 'Admin Dashboard';
require_once __DIR__ . '/../includes/header.php';
require_role('admin');

// --- THE FIX IS HERE ---
// Fetch all student records using the new first_name and last_name columns.
$stmt = $pdo->query("
    SELECT u.first_name, u.last_name, s.student_id_number, p.programme_name
    FROM users u
    JOIN students s ON u.user_id = s.student_user_id
    LEFT JOIN programmes p ON s.programme_id = p.programme_id
    WHERE u.role = 'student'
    ORDER BY u.last_name, u.first_name
");
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<section class="dashboard-section">
    <h2>Manage Student Records</h2>
    <p>Here you can add and  update student records from the database.</p>
    
    <div class="action-buttons">
        <!-- This link now takes you to the "Add Student" page -->
        <a href="add_student.php" class="button">Add New Student</a>
        <a href="update_search.php" class="button">Update Student Record</a>
        <a href="delete_search.php" class="button">Delete Student Record</a>
     
    </div>

    <h3>Current Students</h3>
    <table>
        <thead>
            <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Programme</th>
            
            </tr>
        </thead>
        <tbody>
            <?php if (count($students) > 0): ?>
                <?php foreach ($students as $student): ?>
                <tr>
                    <td><?php echo e($student['student_id_number']); ?></td>
                    <!-- We combine the first and last name for display -->
                    <td><?php echo e($student['first_name'] . ' ' . $student['last_name']); ?></td>
                    <td><?php echo e($student['programme_name'] ?? 'N/A'); ?></td>
            
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No student records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>