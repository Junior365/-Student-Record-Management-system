<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$page_title = 'Delete Student Record';
require_once __DIR__ . '/../includes/header.php';
require_role('admin');

// This page handles BOTH searching AND deleting.
$error_message = '';
$success_message = '';

if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['student_id'])) {
    $student_id_to_delete = $_GET['student_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ? AND role = 'student'");
        $stmt->execute([$student_id_to_delete]);
        if ($stmt->rowCount() > 0) {
            $success_message = "Student record has been successfully deleted.";
        } else {
            $error_message = "Could not find a student with that ID to delete.";
        }
    } catch (PDOException $e) {
        $error_message = "Database error during deletion: " . $e->getMessage();
    }
}

// --- SEARCH LOGIC ---
$search_results = [];
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_term = '%' . $_GET['search'] . '%';
    
    $stmt = $pdo->prepare("
        SELECT u.user_id, u.first_name, u.last_name, s.student_id_number
        FROM users u
        JOIN students s ON u.user_id = s.student_user_id
        WHERE u.role = 'student' AND (u.first_name LIKE ? OR u.last_name LIKE ? OR s.student_id_number LIKE ?)
        ORDER BY u.last_name, u.first_name
    ");
    $stmt->execute([$search_term, $search_term, $search_term]);
    $search_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="form-container">
    <h2>Delete Student Record</h2>
    <p class="alert alert-danger"><strong>Warning:</strong> Deleting a student record is permanent and cannot be undone.</p>

    <?php if ($success_message): ?><div class="alert alert-success"><?php echo $success_message; ?></div><?php endif; ?>
    <?php if ($error_message): ?><div class="alert alert-danger"><?php echo $error_message; ?></div><?php endif; ?>

    <form action="delete_search.php" method="GET" class="search-form">
        <div class="form-group">
            <label for="search">Find Student to Delete</label>
            <input type="text" id="search" name="search" placeholder="Enter name or student number..." value="<?php echo e($_GET['search'] ?? ''); ?>" required>
        </div>
        <button type="submit">Search</button>
    </form>

    <?php if (isset($_GET['search'])): ?>
        <div class="search-results-container">
            <h3>Search Results</h3>
            <?php if (count($search_results) > 0): ?>
                <ul class="results-list">
                    <?php foreach ($search_results as $student): ?>
                        <li>
                            <span><?php echo e($student['first_name'] . ' ' . $student['last_name']); ?> (<?php echo e($student['student_id_number']); ?>)</span>
                            <div class="action-buttons">
                                <a href="delete_search.php?action=delete&student_id=<?php echo e($student['user_id']); ?>&search=<?php echo e($_GET['search'] ?? ''); ?>" 
                                   class="button-delete" 
                                   onclick="return confirm('FINAL WARNING: Are you sure you want to permanently delete this student and all their records?');">
                                   Delete Permanently
                                </a>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No students found matching your search.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>