<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$page_title = 'Edit Student Enrollment';
require_once __DIR__ . '/../includes/header.php';
require_role('admin');

if (!isset($_GET['student_id'])) {
    header("Location: update_search.php");
    exit;
}
$student_id = $_GET['student_id'];

// --- BACKEND LOGIC FOR ALL ACTIONS ---
$error_message = '';
$success_message = '';

// ACTION: Re-register student for a new year
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_year'])) {
    $new_year = $_POST['year_of_study'];
    try {
        $stmt = $pdo->prepare("UPDATE students SET year_of_study = ? WHERE student_user_id = ?");
        $stmt->execute([$new_year, $student_id]);
        $success_message = "Student has been successfully re-registered for Year " . $new_year . ".";
    } catch (PDOException $e) {
        $error_message = "Error updating academic year: " . $e->getMessage();
    }
}

// ACTION: Update multiple marks at once
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_marks'])) {
    $marks = $_POST['marks'];
    try {
        $sql = "UPDATE enrollments SET grade = ? WHERE enrollment_id = ?";
        $stmt = $pdo->prepare($sql);
        foreach ($marks as $enrollment_id => $grade) {
            $grade_to_save = ($grade !== '') ? $grade : null;
            $stmt->execute([$grade_to_save, $enrollment_id]);
        }
        $success_message = "Marks updated successfully!";
    } catch (PDOException $e) {
        $error_message = "Error updating marks: " . $e->getMessage();
    }
}

// ACTION: Remove a single module enrollment
if (isset($_GET['action']) && $_GET['action'] == 'remove_enrollment' && isset($_GET['enrollment_id'])) {
    try {
        $sql = "DELETE FROM enrollments WHERE enrollment_id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$_GET['enrollment_id']]);
        $success_message = "Module removed from student's record.";
    } catch (PDOException $e) {
        $error_message = "Error removing module: " . $e->getMessage();
    }
}

// ACTION: Handle the full Re-registration and Enrollment
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['re_register_student'])) {
    list($programmeId, $new_year, $semester) = explode('-', $_POST['course_semester']);
    $standardModules = $_POST['modules'] ?? [];
    $additionalModules = $_POST['additional_modules'] ?? [];
    $allSelectedModules = array_unique(array_merge($standardModules, $additionalModules));

    $pdo->beginTransaction();
    try {
        $stmt_update_year = $pdo->prepare("UPDATE students SET year_of_study = ? WHERE student_user_id = ?");
        $stmt_update_year->execute([$new_year, $student_id]);

        if (!empty($allSelectedModules)) {
            $sql_enroll = "INSERT INTO enrollments (student_user_id, module_id, semester) VALUES (?, ?, ?)";
            $stmt_enroll = $pdo->prepare($sql_enroll);
            foreach ($allSelectedModules as $moduleId) {
                try {
                    $stmt_enroll->execute([$student_id, $moduleId, $semester]);
                } catch (PDOException $e) {
                    if ($e->errorInfo[1] != 1062) { throw $e; }
                }
            }
        }
        $pdo->commit();
        $success_message = "Student successfully re-registered for Year {$new_year} and enrolled in new modules.";
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error_message = "Database error during re-registration: " . $e->getMessage();
    }
}

// --- FETCH DATA FOR DISPLAY ---
// =================================================================
// === THIS IS THE DATABASE QUERY THAT WAS MISSING - NOW RESTORED ===
// =================================================================
// We fetch the curriculum options for the re-registration form's dropdown
try {
    $curriculum_options_stmt = $pdo->query("
        SELECT DISTINCT p.programme_id, p.programme_name, pm.year_of_study, pm.semester
        FROM programme_modules pm
        JOIN programmes p ON pm.programme_id = p.programme_id
        ORDER BY p.programme_name, pm.year_of_study, pm.semester
    ");
    $curriculum_options = $curriculum_options_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // This provides a helpful error if the `programme_modules` table is missing
    die("Database Error fetching curriculum: " . $e->getMessage());
}

// Fetch student's current details
$stmt = $pdo->prepare("SELECT u.user_id, u.first_name, u.last_name, s.year_of_study FROM users u JOIN students s ON u.user_id = s.student_user_id WHERE u.user_id = ? AND u.role = 'student'");
$stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) { header("Location: update_search.php"); exit; }

// Fetch ALL enrollments for the "Current Modules" table
$enrollments_stmt = $pdo->prepare("SELECT e.enrollment_id, e.grade, e.semester, m.module_code, m.module_name, pm.year_of_study FROM enrollments e JOIN modules m ON e.module_id = m.module_id LEFT JOIN programme_modules pm ON e.module_id = pm.module_id WHERE e.student_user_id = ? GROUP BY e.enrollment_id ORDER BY pm.year_of_study, e.semester, m.module_code");
$enrollments_stmt->execute([$student_id]);
$enrollments = $enrollments_stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="form-container">
    <h3>Managing Enrollment for: <strong><?php echo e($student['first_name'] . ' ' . $student['last_name']); ?></strong></h3>
    <p>Current Academic Year: <strong><?php echo e($student['year_of_study']); ?></strong></p>
    <a href="update_search.php">&laquo; Back to Student Search</a>

    <?php if ($success_message): ?><div class="alert alert-success"><?php echo $success_message; ?></div><?php endif; ?>
    <?php if ($error_message): ?><div class="alert alert-danger"><?php echo $error_message; ?></div><?php endif; ?>

    <!-- UPDATE YEAR FORM -->
    <form action="edit_student.php?student_id=<?php echo e($student_id); ?>" method="POST" class="re-register-form">
        <fieldset>
            <legend>Update Current Academic Year</legend>
            <div class="form-group">
                <label for="year_of_study">Select Academic Year</label>
                <select name="year_of_study" id="year_of_study">
                    <option value="1" <?php if($student['year_of_study'] == 1) echo 'selected'; ?>>Year 1</option>
                    <option value="2" <?php if($student['year_of_study'] == 2) echo 'selected'; ?>>Year 2</option>
                    <option value="3" <?php if($student['year_of_study'] == 3) echo 'selected'; ?>>Year 3</option>
                </select>
            </div>
            <button type="submit" name="update_year">Update Academic Year</button>
        </fieldset>
    </form>

    <!-- UPDATE MARKS FORM -->
    <form action="edit_student.php?student_id=<?php echo e($student_id); ?>" method="POST">
        <fieldset>
            <legend>Current Modules & Marks</legend>
            <?php if (count($enrollments) > 0): ?>
                <table class="marks-table">
                    <thead><tr><th>Year</th><th>Semester</th><th>Module Code</th><th>Module Name</th><th>Mark (%)</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php foreach($enrollments as $enroll): ?>
                        <tr>
                            <td><?php echo e($enroll['year_of_study'] ?? 'N/A'); ?></td>
                            <td><?php echo e($enroll['semester']); ?></td>
                            <td><?php echo e($enroll['module_code']); ?></td>
                            <td><?php echo e($enroll['module_name']); ?></td>
                            <td><input type="number" name="marks[<?php echo e($enroll['enrollment_id']); ?>]" value="<?php echo e($enroll['grade']); ?>" min="0" max="100" class="mark-input"></td>
                            <td><a href="edit_student.php?student_id=<?php echo e($student_id); ?>&action=remove_enrollment&enrollment_id=<?php echo e($enroll['enrollment_id']); ?>" class="remove-btn" onclick="return confirm('Are you sure you want to remove this module from the student record?');">&times;</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="submit" name="update_marks">Update All Marks</button>
            <?php else: ?>
                <p>This student is not currently enrolled in any modules.</p>
            <?php endif; ?>
        </fieldset>
    </form>

    <!-- RE-REGISTRATION & ENROLLMENT FORM -->
    <form action="edit_student.php?student_id=<?php echo e($student_id); ?>" method="POST">
        <fieldset class="re-register-form">
            <legend>Re-register and Enroll in New Modules</legend>
            <p>Use this form to enroll the student in a new semester's modules.</p>
            <div class="form-row">
                <div class="form-group">
                    <label for="course_semester">Select New Course and Semester</label>
                    <select id="course_semester" name="course_semester" required>
                        <option value="">-- Select a Course and Semester --</option>
                        <?php foreach ($curriculum_options as $option): ?>
                            <option value="<?php echo e($option['programme_id'] . '-' . $option['year_of_study'] . '-' . $option['semester']); ?>">
                                <?php echo e($option['programme_name'] . ' - Year ' . $option['year_of_study'] . ' Semester ' . $option['semester']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Standard Modules for Selected Semester</label>
                    <div id="modules-container" class="modules-container">
                        <small>-- Please select a course first --</small>
                    </div>
                </div>
            </div>
            <div id="additional-module-search-container">
                <label for="additional-module-search">Add Additional Module (Elective/Other)</label>
                <input type="text" id="additional-module-search" placeholder="Search by module code or name...">
                <ul id="search-results"></ul>
                <ul id="additional-modules-list"></ul>
            </div>
            <button type="submit" name="re_register_student" style="margin-top: 20px;">Enroll in Selected Modules</button>
        </fieldset>
    </form>
</div>

<!-- Complete and unabbreviated JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // This is the full, correct JavaScript that was missing before.
    const courseSemesterSelect = document.getElementById('course_semester');
    const modulesContainer = document.getElementById('modules-container');
    const searchInput = document.getElementById('additional-module-search');
    const searchResults = document.getElementById('search-results');
    const additionalModulesList = document.getElementById('additional-modules-list');

    courseSemesterSelect.addEventListener('change', function() {
        modulesContainer.innerHTML = '<small>Loading...</small>';
        const selectedValue = this.value;
        if (!selectedValue) {
            modulesContainer.innerHTML = '<small>-- Please select a course first --</small>';
            return;
        }
        const [programmeId, year, semester] = selectedValue.split('-');
        fetch(`get_modules.php?programme_id=${programmeId}&year=${year}&semester=${semester}`)
            .then(response => response.json())
            .then(data => {
                modulesContainer.innerHTML = '';
                if (data.length > 0) {
                    data.forEach(module => {
                        const optionDiv = document.createElement('div');
                        optionDiv.className = 'module-option';
                        const checkbox = document.createElement('input');
                        checkbox.type = 'checkbox';
                        checkbox.name = 'modules[]';
                        checkbox.value = module.module_id;
                        checkbox.id = 'module-' + module.module_id;
                        const label = document.createElement('label');
                        label.htmlFor = 'module-' + module.module_id;
                        label.textContent = `${module.module_code} - ${module.module_name}`;
                        optionDiv.appendChild(checkbox);
                        optionDiv.appendChild(label);
                        modulesContainer.appendChild(optionDiv);
                    });
                } else {
                    modulesContainer.innerHTML = '<small>-- No modules found for this semester --</small>';
                }
            })
            .catch(error => {
                console.error('Error fetching modules:', error);
                modulesContainer.innerHTML = '<small>-- Error loading modules --</small>';
            });
    });

    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.trim();
        if (searchTerm.length < 2) {
            searchResults.innerHTML = '';
            return;
        }
        const excludeIds = [];
        document.querySelectorAll('input[name="modules[]"]:checked').forEach(cb => excludeIds.push(cb.value));
        document.querySelectorAll('input[name="additional_modules[]"]').forEach(input => excludeIds.push(input.value));
        const excludeQuery = excludeIds.map(id => `exclude[]=${id}`).join('&');
        fetch(`search_modules.php?term=${searchTerm}&${excludeQuery}`)
            .then(response => response.json())
            .then(data => {
                searchResults.innerHTML = '';
                if (data.length > 0) {
                    data.forEach(module => {
                        const li = document.createElement('li');
                        li.textContent = `${module.module_code} - ${module.module_name}`;
                        li.dataset.moduleId = module.module_id;
                        li.dataset.moduleText = `${module.module_code} - ${module.module_name}`;
                        li.dataset.semester = module.semester || '1';
                        searchResults.appendChild(li);
                    });
                }
            });
    });

    searchResults.addEventListener('click', function(e) {
        if (e.target.tagName === 'LI') {
            const moduleId = e.target.dataset.moduleId;
            const moduleText = e.target.dataset.moduleText;
            addModuleToList(moduleId, moduleText);
            searchInput.value = '';
            searchResults.innerHTML = '';
        }
    });

    function addModuleToList(id, text) {
        const li = document.createElement('li');
        li.dataset.moduleId = id;
        const textSpan = document.createElement('span');
        textSpan.textContent = text;
        const removeBtn = document.createElement('span');
        removeBtn.textContent = '✖';
        removeBtn.className = 'remove-btn';
        removeBtn.title = 'Remove Module';
        removeBtn.onclick = function() {
            li.remove();
        };
        const hiddenInput = document.createElement('input');
        hiddenInput.type = 'hidden';
        hiddenInput.name = 'additional_modules[]';
        hiddenInput.value = id;
        li.appendChild(textSpan);
        li.appendChild(removeBtn);
        li.appendChild(hiddenInput);
        additionalModulesList.appendChild(li);
    }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>