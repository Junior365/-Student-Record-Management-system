<?php
// This is our simple API endpoint. It only returns JSON data.

require_once __DIR__ . '/../config.php'; // For the $pdo connection

// Check if the required parameters are provided in the URL
if (!isset($_GET['programme_id']) || !isset($_GET['year']) || !isset($_GET['semester'])) {
    http_response_code(400); // Bad Request
    echo json_encode(['error' => 'Missing required parameters.']);
    exit;
}

$programmeId = $_GET['programme_id'];
$year = $_GET['year'];
$semester = $_GET['semester'];

try {
    // Prepare a query to get all modules for the selected curriculum
    $sql = "
        SELECT m.module_id, m.module_name, m.module_code
        FROM modules m
        JOIN programme_modules pm ON m.module_id = pm.module_id
        WHERE pm.programme_id = ? AND pm.year_of_study = ? AND pm.semester = ?
        ORDER BY m.module_name
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$programmeId, $year, $semester]);
    $modules = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Set the content type header to application/json
    header('Content-Type: application/json');
    
    // Echo the modules as a JSON string
    echo json_encode($modules);

} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    // For debugging, we can show the actual error message.
    // In a live production environment, you would log this instead.
    echo json_encode(['error' => 'Database query failed.', 'message' => $e->getMessage()]);
}