<?php
require_once __DIR__ . '/../config.php';

$searchTerm = $_GET['term'] ?? '';
$excludeIds = $_GET['exclude'] ?? [];

if (empty($searchTerm)) {
    echo json_encode([]);
    exit;
}

try {
    $placeholders = !empty($excludeIds) ? implode(',', array_fill(0, count($excludeIds), '?')) : '';
    
    // --- THE FIX IS HERE ---
    // The query now JOINS with programme_modules to get the correct semester for each module.
    $sql = "
        SELECT m.module_id, m.module_name, m.module_code, pm.semester
        FROM modules m
        LEFT JOIN programme_modules pm ON m.module_id = pm.module_id
        WHERE (m.module_name LIKE ? OR m.module_code LIKE ?)
    ";

    if (!empty($excludeIds)) {
        $sql .= " AND m.module_id NOT IN ($placeholders)";
    }
    
    // We group by module_id in case a module is in multiple programmes
    $sql .= " GROUP BY m.module_id LIMIT 10";

    $stmt = $pdo->prepare($sql);
    
    $params = ["%$searchTerm%", "%$searchTerm%"];
    if (!empty($excludeIds)) {
        $params = array_merge($params, $excludeIds);
    }
    
    $stmt->execute($params);
    $modules = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: application/json');
    echo json_encode($modules);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database query failed.']);
}