<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$page_title = 'Update Student Record';
require_once __DIR__ . '/../includes/header.php';
require_role('admin');

// This page ONLY handles searching. The 'edit_student.php' file handles the actual updating.
$search_results = [];
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_term = '%' . $_GET['search'] . '%';
    
    $stmt = $pdo->prepare("
        SELECT u.user_id, u.first_name, u.last_name, s.student_id_number
        FROM users u
        JOIN students s ON u.user_id = s.student_user_id
        WHERE u.role = 'student' AND (u.first_name LIKE ? OR u.last_name LIKE ? OR s.student_id_number LIKE ?)
        ORDER BY u.last_name, u.first_name
    ");
    $stmt->execute([$search_term, $search_term, $search_term]);
    $search_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="form-container">
    <h2>Update Student Record</h2>
    <p>Search for a student by their name or student number to manage their modules and marks.</p>

    <form action="update_search.php" method="GET" class="search-form">
        <div class="form-group">
            <label for="search">Find Student to Update</label>
            <input type="text" id="search" name="search" placeholder="Enter name or student number..." value="<?php echo e($_GET['search'] ?? ''); ?>" required>
        </div>
        <button type="submit">Search</button>
    </form>

    <?php if (isset($_GET['search'])): ?>
        <div class="search-results-container">
            <h3>Search Results</h3>
            <?php if (count($search_results) > 0): ?>
                <ul class="results-list">
                    <?php foreach ($search_results as $student): ?>
                        <li>
                            <span><?php echo e($student['first_name'] . ' ' . $student['last_name']); ?> (<?php echo e($student['student_id_number']); ?>)</span>
                            <div class="action-buttons">
                                <a href="edit_student.php?student_id=<?php echo e($student['user_id']); ?>" class="button">Edit/Marks</a>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No students found matching your search.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>