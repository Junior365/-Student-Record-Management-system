// This script is loaded on the login page.
// You can add client-side validation or other interactive features here.

document.addEventListener('DOMContentLoaded', () => {
    // Example: You could add code to focus the username field on page load.
    const usernameField = document.getElementById('username');
    if (usernameField) {
        usernameField.focus();
    }
});