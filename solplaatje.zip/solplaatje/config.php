<?php
// Database configuration settings
define('DB_HOST', 'localhost');
define('DB_NAME', 'solplaatje_university');
define('DB_USER', 'root');
define('DB_PASS', ''); // Default XAMPP password is empty

// Site Name
define('SITE_NAME', 'Sol Plaatje University');

// Establish a database connection using PDO for security
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    // Set the PDO error mode to exception to catch errors
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
    // If connection fails, stop the script and show an error
    die("ERROR: Could not connect to the database. " . $e->getMessage());
}

// Start the session, which is needed for login management
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>