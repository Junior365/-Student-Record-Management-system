<?php
// This is a developer tool to log in directly as the administrator.

// 1. Include the configuration to start the session.
require_once 'config.php';

// --- ADMIN DETAILS (from your database) ---
$admin_user_id      = 1;          // The user_id for the admin user
$admin_login_id     = 'admin';    // The loginid for the admin user
$admin_first_name   = 'Admin';    // The first_name for the admin user
$admin_last_name    = 'User';     // The last_name for the admin user
// ----------------------------------------


// --- DO NOT EDIT BELOW THIS LINE ---

// Manually create a "logged-in" session for the administrator.
$_SESSION['loggedin'] = true;
$_SESSION['user_id'] = $admin_user_id;
$_SESSION['username'] = $admin_login_id;
$_SESSION['user_role'] = 'admin'; // Set the role to 'admin'
$_SESSION['full_name'] = $admin_first_name . ' ' . $admin_last_name;

// Immediately redirect to the ADMIN dashboard.
header("Location: admin/dashboard.php");
exit; // Stop the script

?>