<?php
// This file assumes config.php (which starts the session) has been included.

/**
 * Checks if a user is currently logged in.
 * @return bool True if logged in, false otherwise.
 */
function is_logged_in() {
    return isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;
}

/**
 * If the user is not logged in, redirects them to the login page.
 */
function require_login() {
    if (!is_logged_in()) {
        header("Location: /solplaatje/index.php");
        exit;
    }
}

/**
 * Checks if the logged-in user has the required role.
 * @param string $role The required role (e.g., 'admin', 'student').
 */
function require_role($role) {
    require_login(); // A user must be logged in to have a role
    if ($_SESSION['user_role'] !== $role) {
        // Optional: Add a message for the user.
        // $_SESSION['error_message'] = "Access Denied.";
        // Redirect to their own dashboard
        header("Location: /solplaatje/index.php");
        exit;
    }
}

/**
 * A wrapper for htmlspecialchars to prevent XSS attacks. Makes outputting data safer.
 * @param string|null $string The string to sanitize.
 * @return string The sanitized string.
 */
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}
?>