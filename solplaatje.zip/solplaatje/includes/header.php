<?php
// This file is the first thing included on every protected page.

// 1. It loads the configuration, starts the session, and connects to the DB.
require_once __DIR__ . '/../config.php';

// 2. It loads our helper functions (like require_login(), e()).
require_once __DIR__ . '/functions.php';

// 3. It runs the security check to ensure only logged-in users can see the page.
require_login();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- The page title is set dynamically by the page that includes this header -->
    <title><?php echo e($page_title ?? 'Dashboard'); ?> - <?php echo SITE_NAME; ?></title>
    
    <!-- Link to the main stylesheet using an absolute path for reliability -->
    <link rel="stylesheet" href="/solplaatje/assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <!-- Display the Site Name, which is set in config.php -->
            <h1><?php echo SITE_NAME; ?></h1>
            <nav>
                <!-- Welcome the logged-in user by their full name from the session -->
                <span>Welcome, <?php echo e($_SESSION['full_name']); ?>!</span>
                
                <!-- Provide a link to the logout script -->
                <a href="/solplaatje/logout.php" class="logout-btn">Logout</a>
            </nav>
        </header>
        <main>