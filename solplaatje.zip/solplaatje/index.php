<?php
require_once 'config.php'; // Connect to database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $loginid = trim($_POST['loginid']);
    $password = trim($_POST['password']);
    $selected_role = trim($_POST['role']);

    // Fetch the user by loginid
    $stmt = $pdo->prepare("SELECT * FROM users WHERE loginid = ?");
    $stmt->execute([$loginid]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Handle both hashed and plain-text passwords
        if (strpos($user['password'], '$2y$') === 0) {
            $passwordMatch = password_verify($password, $user['password']);
        } else {
            $passwordMatch = ($password === $user['password']);
        }

        // Verify password and role
        if ($passwordMatch && strtolower($user['role']) === strtolower($selected_role)) {
            // Start session
            $_SESSION['loggedin'] = true;
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['loginid'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['full_name'] = $user['first_name'] . ' ' . $user['last_name'];

            // Redirect based on role
            if ($user['role'] === 'admin') {
                header("Location: admin/dashboard.php");
            } elseif ($user['role'] === 'lecturer') {
                header("Location: lecturer/dashboard.php");
            } elseif ($user['role'] === 'student') {
                header("Location: student/dashboard.php");
            } else {
                header("Location: index.php");
            }
            exit;
        } else {
            $error = "Invalid credentials or incorrect role selected.";
        }
    } else {
        $error = "No user found with that Login ID.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Login | Sol Plaatje University</title>
  <style>
    body {
      font-family: Arial;
      background-color: #f3f4f6;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
    .login-box {
      width: 360px;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    h2 { text-align: center; color: #333; margin-bottom: 20px; }
    label { display: block; margin-top: 10px; font-weight: bold; color: #555; }
    input, select {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    button {
      width: 100%;
      padding: 10px;
      margin-top: 15px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-weight: bold;
    }
    button:hover { background-color: #0056b3; }
    .error {
      margin-top: 15px;
      text-align: center;
      color: red;
      font-weight: bold;
    }
  </style>
</head>
<body>

<div class="login-box">
  <h2>Student Database Login</h2>

  <form method="POST" action="">
    <label for="loginid">Username</label>
    <input type="text" name="loginid" id="loginid" required>

    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>

    <label for="role">Select Role</label>
    <select name="role" id="role" required>
      <option value="">-- Select Role --</option>
      <option value="admin">Admin</option>
      <option value="student">Student</option>
    </select>

    <button type="submit">Login</button>
  </form>

  <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>
</div>

</body>
</html>