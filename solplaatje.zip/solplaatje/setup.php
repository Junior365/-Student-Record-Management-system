<?php
require_once 'config.php';

// --- Create Initial Admin User ---
// IMPORTANT: For security, delete this file after you have run it once.
$admin_username = 'admin';
$admin_password = 'admin123'; // Use a strong password in a real environment
$admin_full_name = 'Administrator';

// Use PHP's password_hash() to securely hash the password
$password_hash = password_hash($admin_password, PASSWORD_DEFAULT);

try {
    $sql = "INSERT INTO users (username, password_hash, full_name, role) VALUES (:username, :password, :name, 'admin')";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'username' => $admin_username,
        'password' => $password_hash,
        'name' => $admin_full_name
    ]);
    echo "Admin account for '{$admin_username}' created successfully!";
} catch (PDOException $e) {
    // Error code 1062 is for a duplicate entry
    if ($e->errorInfo[1] == 1062) {
        die("Error: The username '{$admin_username}' already exists.");
    } else {
        die("Error creating admin account: " . $e->getMessage());
    }
}
?>