-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 10, 2025 at 11:00 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `solplaatje_university`
--

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `enrollment_id` int(11) NOT NULL,
  `student_user_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `grade` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`enrollment_id`, `student_user_id`, `module_id`, `semester`, `grade`) VALUES
(1, 2, 1, 1, 85.00),
(2, 2, 2, 2, 78.00),
(3, 2, 3, 1, 91.00),
(4, 5, 6, 2, 56.00),
(7, 7, 21, 1, 78.00),
(8, 7, 25, 1, 23.00),
(9, 7, 23, 1, 67.00),
(10, 7, 19, 1, 98.00),
(11, 8, 20, 2, NULL),
(12, 8, 27, 2, NULL),
(13, 8, 22, 2, NULL),
(14, 8, 18, 2, NULL),
(15, 8, 24, 2, NULL),
(16, 8, 26, 2, NULL),
(21, 9, 34, 2, 45.00),
(22, 9, 33, 2, 78.00),
(23, 9, 35, 2, 89.00),
(24, 9, 36, 2, 33.00),
(25, 9, 37, 2, 90.00),
(26, 9, 7, 2, NULL),
(28, 7, 27, 2, 54.00),
(29, 7, 18, 2, 90.00),
(32, 7, 26, 2, 67.00),
(33, 7, 20, 2, 45.00),
(34, 10, 34, 2, 89.00),
(35, 10, 33, 2, 56.00),
(36, 10, 35, 2, 90.00),
(37, 10, 36, 2, 90.00),
(38, 10, 37, 2, 67.00),
(39, 11, 34, 2, NULL),
(40, 11, 33, 2, NULL),
(41, 11, 35, 2, NULL),
(42, 11, 36, 2, NULL),
(43, 11, 37, 2, NULL),
(44, 12, 12, 1, NULL),
(45, 12, 38, 1, NULL),
(46, 12, 11, 1, NULL),
(47, 12, 10, 1, NULL),
(61, 7, 30, 1, 56.00),
(62, 7, 29, 1, 67.00),
(63, 7, 31, 1, 56.00),
(64, 7, 28, 1, 78.00),
(65, 7, 32, 1, 89.00);

-- --------------------------------------------------------

--
-- Table structure for table `lecturers`
--

CREATE TABLE `lecturers` (
  `lecturer_user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lecturers`
--

INSERT INTO `lecturers` (`lecturer_user_id`) VALUES
(4);

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `module_id` int(11) NOT NULL,
  `module_code` varchar(10) NOT NULL,
  `module_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `credits` int(11) DEFAULT 15
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`module_id`, `module_code`, `module_name`, `description`, `credits`) VALUES
(1, 'CS101', 'Introduction to Programming', NULL, 15),
(2, 'DB202', 'Database Systems', NULL, 20),
(3, 'MA101', 'Calculus I', NULL, 15),
(4, 'DS101', 'Introduction to Python', NULL, 15),
(5, 'STAT101', 'Statistics I', NULL, 15),
(6, 'MATH102', 'Linear Algebra', NULL, 15),
(7, 'DS201', 'Machine Learning I', NULL, 20),
(8, 'CS102', 'Data Structures & Algorithms', NULL, 20),
(9, 'NDSE731', 'Data Security', NULL, 16),
(10, 'NSIP731', 'Signal and Image processing', NULL, 16),
(11, 'NMST731', 'Multivariate Statistics', NULL, 16),
(12, 'NFLA731', 'Formal language and automata', NULL, 16),
(13, 'NMAL732', 'Machine Learning', NULL, 16),
(14, 'NAAA732', 'Advanced algorithm analysis', NULL, 16),
(15, 'NDAS732', 'Data Science III: Simulation and Modelling', NULL, 16),
(16, 'NCSP730', 'Capstone Project', NULL, 24),
(17, 'NBCA511', 'Basic Computer Organization and Architecture', NULL, 10),
(18, 'NDSA512', 'Data Structures and Algorithms', NULL, 10),
(19, 'NSTA515', 'Introduction to Statistics', NULL, 16),
(20, 'NMAT514', 'Algebra', NULL, 16),
(21, 'NMAT515', 'Calculus', NULL, 16),
(22, 'NDAS512', 'Data Science I', NULL, 10),
(23, 'NIAP513', 'Introduction to Algorithms and Programming', NULL, 10),
(24, 'NAPM512', 'Introduction to Numerical methods and mathematical modelling', NULL, 16),
(25, 'SCOR511', 'Core Curriculum 1', NULL, 8),
(26, 'NSTA514', 'Probability Theory', NULL, 16),
(27, 'SCOR612', 'Core Curriculum 2', NULL, 8),
(28, 'NOCN621', 'Operating Systems and Computer Networks', NULL, 12),
(29, 'NDAS621', 'Data Science 2A: Data Analysis and Visualization', NULL, 12),
(30, 'NMAT623', 'Advanced calculus', NULL, 20),
(31, 'NDIM621', 'Discrete Mathematics', NULL, 12),
(32, 'NSTI621', 'Statistical Inference', NULL, 12),
(33, 'NDAS622', 'Data Science 2B: Large scale Data analysis and visualization', NULL, 12),
(34, 'NAAA622', 'Applications and Analysis of Algorithms', NULL, 12),
(35, 'NDBS622', 'Database Systems', NULL, 12),
(36, 'NMAT624', 'Linear Algebra', NULL, 10),
(37, 'NDOM622', 'Optimization Methods for Data Science', NULL, 12),
(38, 'NMAL733', 'Machine Learning', NULL, 16),
(39, 'NDPE731', 'Data Privacy and Ethics', NULL, 16);

-- --------------------------------------------------------

--
-- Table structure for table `module_lecturers`
--

CREATE TABLE `module_lecturers` (
  `module_id` int(11) NOT NULL,
  `lecturer_user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `module_lecturers`
--

INSERT INTO `module_lecturers` (`module_id`, `lecturer_user_id`) VALUES
(1, 4),
(2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `programmes`
--

CREATE TABLE `programmes` (
  `programme_id` int(11) NOT NULL,
  `programme_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `programmes`
--

INSERT INTO `programmes` (`programme_id`, `programme_name`) VALUES
(1, 'BSc in Computer Science'),
(2, 'BA in Arts'),
(3, 'BSc in Data Science'),
(4, 'BSc in Data Science (DSC701)'),
(5, 'BSc in Data Science (DSC702)');

-- --------------------------------------------------------

--
-- Table structure for table `programme_modules`
--

CREATE TABLE `programme_modules` (
  `programme_module_id` int(11) NOT NULL,
  `programme_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `year_of_study` int(1) NOT NULL,
  `semester` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `programme_modules`
--

INSERT INTO `programme_modules` (`programme_module_id`, `programme_id`, `module_id`, `year_of_study`, `semester`) VALUES
(1, 5, 17, 1, 1),
(2, 5, 23, 1, 1),
(3, 5, 21, 1, 1),
(4, 5, 19, 1, 1),
(5, 5, 25, 1, 1),
(8, 5, 24, 1, 2),
(9, 5, 22, 1, 2),
(10, 5, 18, 1, 2),
(11, 5, 20, 1, 2),
(12, 5, 26, 1, 2),
(13, 5, 27, 1, 2),
(15, 5, 29, 2, 1),
(16, 5, 31, 2, 1),
(17, 5, 30, 2, 1),
(18, 5, 28, 2, 1),
(19, 5, 32, 2, 1),
(22, 5, 34, 2, 2),
(23, 5, 33, 2, 2),
(24, 5, 35, 2, 2),
(25, 5, 37, 2, 2),
(26, 5, 36, 2, 2),
(29, 5, 12, 3, 1),
(30, 5, 38, 3, 1),
(31, 5, 11, 3, 1),
(32, 5, 10, 3, 1),
(36, 5, 14, 3, 2),
(37, 5, 16, 3, 2),
(38, 5, 15, 3, 2),
(39, 5, 39, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_user_id` int(11) NOT NULL,
  `student_id_number` varchar(10) NOT NULL,
  `programme_id` int(11) DEFAULT NULL,
  `year_of_study` int(1) NOT NULL DEFAULT 1,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_user_id`, `student_id_number`, `programme_id`, `year_of_study`, `email`, `phone_number`) VALUES
(2, 'S12345', 1, 1, 'alex.doe@university.com', NULL),
(5, '202417124', 3, 1, '202417124@spu.ac.za', '0817759353'),
(7, '20241234', 5, 2, '20241234@ac.za', '0816043418'),
(8, '202412567', 5, 1, 'admin@gmail.com', '09876'),
(9, '2024678', 5, 2, '2024678@gmail.com', '0817759343'),
(10, '987654', 5, 2, '987654@gmail.com', '012345678'),
(11, '039424889', 5, 2, '039424889@spu.ac.za', '0111111111'),
(12, '202549518', 5, 3, '202549518@spu.ac.za', '172839456');

-- --------------------------------------------------------

--
-- Table structure for table `student_contacts`
--

CREATE TABLE `student_contacts` (
  `contact_id` int(11) NOT NULL,
  `student_user_id` int(11) NOT NULL,
  `home_address` text DEFAULT NULL,
  `next_of_kin_name` varchar(100) DEFAULT NULL,
  `next_of_kin_contact` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_contacts`
--

INSERT INTO `student_contacts` (`contact_id`, `student_user_id`, `home_address`, `next_of_kin_name`, `next_of_kin_contact`) VALUES
(1, 5, '26 springbok', 'Juju', '0783936164'),
(3, 7, '26 Springbok avenue', 'Jorge', '012345678'),
(4, 8, 'there 1234', 'kev', '00000'),
(5, 9, '26 Brand avenue', 'Jane', '000000000'),
(6, 10, '45 Springbok Avenue', 'bobler', '123456789'),
(7, 11, '25 Springbok Avenue', 'Seelinah', 'Mahaila'),
(8, 12, '23 Brodly street', 'Ernest', '081234567');

-- --------------------------------------------------------

--
-- Table structure for table `study_progress`
--

CREATE TABLE `study_progress` (
  `id` int(11) NOT NULL,
  `student_user_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `hours_studied` decimal(5,2) DEFAULT 0.00,
  `current_topic` varchar(255) DEFAULT NULL,
  `is_completed` tinyint(1) DEFAULT 0,
  `required_hours` int(11) DEFAULT 0,
  `hours_per_topic` decimal(4,2) DEFAULT 0.00,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `loginid` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `role` enum('student','admin','lecturer') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `loginid`, `password`, `first_name`, `last_name`, `role`) VALUES
(1, 'admin', 'Test@12345', 'Admin', 'User', 'admin'),
(2, 'alex.doe', 'studentpass', 'Alex', 'Doe', 'student'),
(4, 'prof.jones', 'lecturerpass', 'Professor', 'Jones', 'lecturer'),
(5, '202417124', '$2y$10$A6PS6PGJJPRpgQXAXfjD0uEMwhSEqIe0zxJfm2B9CCSxOKBhcs.TK', 'Adrian', 'Machoie', 'student'),
(7, '20241234', 'Password123', 'Thalitha', 'Row', 'student'),
(8, '202412567', 'Password123', 'roxy', 'lane', 'student'),
(9, '2024678', 'Password123', 'Josh', 'Mate', 'student'),
(10, '987654', 'Password123', 'Bob', 'Builder', 'student'),
(11, '039424889', 'Password123', 'Caleb', 'Machaila', 'student'),
(12, '202549518', 'Password123', 'Naomi', 'Machoie', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`enrollment_id`),
  ADD KEY `enrollments_fk_student` (`student_user_id`),
  ADD KEY `enrollments_fk_module` (`module_id`);

--
-- Indexes for table `lecturers`
--
ALTER TABLE `lecturers`
  ADD PRIMARY KEY (`lecturer_user_id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`module_id`),
  ADD UNIQUE KEY `module_code` (`module_code`);

--
-- Indexes for table `module_lecturers`
--
ALTER TABLE `module_lecturers`
  ADD PRIMARY KEY (`module_id`,`lecturer_user_id`),
  ADD KEY `ml_fk_lecturer` (`lecturer_user_id`);

--
-- Indexes for table `programmes`
--
ALTER TABLE `programmes`
  ADD PRIMARY KEY (`programme_id`);

--
-- Indexes for table `programme_modules`
--
ALTER TABLE `programme_modules`
  ADD PRIMARY KEY (`programme_module_id`),
  ADD KEY `fk_pm_programme` (`programme_id`),
  ADD KEY `fk_pm_module` (`module_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_user_id`),
  ADD UNIQUE KEY `student_id_number` (`student_id_number`),
  ADD KEY `programme_id` (`programme_id`);

--
-- Indexes for table `student_contacts`
--
ALTER TABLE `student_contacts`
  ADD PRIMARY KEY (`contact_id`),
  ADD UNIQUE KEY `student_user_id` (`student_user_id`);

--
-- Indexes for table `study_progress`
--
ALTER TABLE `study_progress`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_student_module` (`student_user_id`,`module_id`),
  ADD KEY `module_id` (`module_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`loginid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `enrollment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `programmes`
--
ALTER TABLE `programmes`
  MODIFY `programme_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `programme_modules`
--
ALTER TABLE `programme_modules`
  MODIFY `programme_module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `student_contacts`
--
ALTER TABLE `student_contacts`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `study_progress`
--
ALTER TABLE `study_progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `enrollments_fk_module` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `enrollments_fk_student` FOREIGN KEY (`student_user_id`) REFERENCES `students` (`student_user_id`) ON DELETE CASCADE;

--
-- Constraints for table `lecturers`
--
ALTER TABLE `lecturers`
  ADD CONSTRAINT `lecturers_fk_user` FOREIGN KEY (`lecturer_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `module_lecturers`
--
ALTER TABLE `module_lecturers`
  ADD CONSTRAINT `ml_fk_lecturer` FOREIGN KEY (`lecturer_user_id`) REFERENCES `lecturers` (`lecturer_user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ml_fk_module` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`) ON DELETE CASCADE;

--
-- Constraints for table `programme_modules`
--
ALTER TABLE `programme_modules`
  ADD CONSTRAINT `fk_pm_module` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_pm_programme` FOREIGN KEY (`programme_id`) REFERENCES `programmes` (`programme_id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_fk_programme` FOREIGN KEY (`programme_id`) REFERENCES `programmes` (`programme_id`),
  ADD CONSTRAINT `students_fk_user` FOREIGN KEY (`student_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `student_contacts`
--
ALTER TABLE `student_contacts`
  ADD CONSTRAINT `fk_student_contact_user` FOREIGN KEY (`student_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `study_progress`
--
ALTER TABLE `study_progress`
  ADD CONSTRAINT `study_progress_ibfk_1` FOREIGN KEY (`student_user_id`) REFERENCES `students` (`student_user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `study_progress_ibfk_2` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
