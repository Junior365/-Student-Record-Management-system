<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$page_title = 'Student Dashboard';
require_once __DIR__ . '/../includes/header.php';
require_role('student');

$student_user_id = $_SESSION['user_id'];


$stmt_details = $pdo->prepare("
    SELECT u.first_name, u.last_name, s.student_id_number, s.email, p.programme_name
    FROM users u
    JOIN students s ON u.user_id = s.student_user_id
    LEFT JOIN programmes p ON s.programme_id = p.programme_id
    WHERE u.user_id = :user_id
");
$stmt_details->execute(['user_id' => $student_user_id]);
$student = $stmt_details->fetch(PDO::FETCH_ASSOC);


$stmt_records = $pdo->prepare("
    SELECT m.module_code, m.module_name, e.semester, e.grade
    FROM enrollments e
    JOIN modules m ON e.module_id = m.module_id
    WHERE e.student_user_id = :user_id
    ORDER BY e.semester, m.module_code
");
$stmt_records->execute(['user_id' => $student_user_id]);
$records = $stmt_records->fetchAll(PDO::FETCH_ASSOC);
?>

<section class="dashboard-section">
    <h2>My Personal Details</h2>
    <?php if ($student): ?>
        <div class="details-grid">
            <p><strong>Name:</strong> <?php echo e($student['first_name'] . ' ' . $student['last_name']); ?></p>
            <p><strong>Student ID:</strong> <?php echo e($student['student_id_number']); ?></p>
            <p><strong>Email:</strong> <?php echo e($student['email']); ?></p>
            <p><strong>Programme:</strong> <?php echo e($student['programme_name'] ?? 'N/A'); ?></p>
        </div>
    <?php else: ?>
        <p>Could not find student details.</p>
    <?php endif; ?>
</section>

<section class="dashboard-section">
    <h2>My Academic Record Summary</h2>
    <table>
      
        <thead><tr><th>Module Code</th><th>Module Name</th><th>Semester</th><th>Grade</th></tr></thead>
        <tbody>
            <?php if (count($records) > 0): ?>
                <?php foreach ($records as $record): ?>
                <tr>
                    <td><?php echo e($record['module_code']); ?></td>
                    <td><?php echo e($record['module_name']); ?></td>
                    <td><?php echo e($record['semester']); ?></td>
                    <td><?php echo e($record['grade'] ? number_format($record['grade'], 2) . '%' : 'In Progress'); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="4">You are not currently enrolled in any modules.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

 
    <div style="margin-top: 30px; padding: 20px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">
        <h3>Track Your Study Time</h3>
        <p>Monitor your study progress and hours for each module you're enrolled in.</p>
        <a href="student_tracking.php" class="btn btn-primary" style="padding: 10px 20px; font-size: 16px;">
            Go to Study Tracking
        </a>
    </div>
</section>


<section class="dashboard-section">
    <h2>Generate Academic Transcript</h2>
    <p>Select a transcript to view or download.</p>
    <div class="transcript-options">
        <ul>
            <li><strong>Year 1:</strong>
                <a href="transcript.php?year=1&semester=1">Semester 1</a> | 
                <a href="transcript.php?year=1&semester=2">Semester 2</a> | 
                <a href="transcript.php?year=1&semester=all">Full Year 1</a>
            </li>
            <li><strong>Year 2:</strong>
                <a href="transcript.php?year=2&semester=1">Semester 1</a> | 
                <a href="transcript.php?year=2&semester=2">Semester 2</a> | 
                <a href="transcript.php?year=2&semester=all">Full Year 2</a>
            </li>
            <li><strong>Year 3:</strong>
                <a href="transcript.php?year=3&semester=1">Semester 1</a> | 
                <a href="transcript.php?year=3&semester=2">Semester 2</a> | 
                <a href="transcript.php?year=3&semester=all">Full Year 3</a>
            </li>
            <li class="full-transcript">
                <a href="transcript.php?year=all"><strong>View Full Academic Transcript (All Years)</strong></a>
            </li>
        </ul>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>