<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/fpdf/fpdf.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['user_role'] !== 'student') {
    die('Access Denied.');
}

$student_user_id = $_SESSION['user_id'];
$year_filter = $_GET['year'] ?? 'all';
$semester_filter = $_GET['semester'] ?? 'all';

// --- THE FIX IS HERE ---
// This query now correctly fetches the 'first_name' and 'last_name' columns.
$student_details_stmt = $pdo->prepare("SELECT u.first_name, u.last_name, sc.home_address FROM users u LEFT JOIN student_contacts sc ON u.user_id = sc.student_user_id WHERE u.user_id = ?");
$student_details_stmt->execute([$student_user_id]);
$student = $student_details_stmt->fetch(PDO::FETCH_ASSOC);

// The rest of the logic is correct
$params = [$student_user_id];
$sql_where = "";
$transcript_title = "Full Academic Transcript";

if ($year_filter !== 'all') {
    if ($semester_filter !== 'all') {
        $sql_where = " AND pm.year_of_study = ? AND e.semester = ?";
        array_push($params, $year_filter, $semester_filter);
        $transcript_title = "Academic Transcript - Year $year_filter Semester $semester_filter";
    } else {
        $sql_where = " AND pm.year_of_study = ?";
        $params[] = $year_filter;
        $transcript_title = "Academic Transcript - Full Year $year_filter";
    }
}

$records_stmt = $pdo->prepare("
    SELECT m.module_name, e.grade, e.semester, pm.year_of_study 
    FROM enrollments e
    JOIN modules m ON e.module_id = m.module_id
    LEFT JOIN programme_modules pm ON e.module_id = pm.module_id
    WHERE e.student_user_id = ? {$sql_where}
    GROUP BY e.enrollment_id
    ORDER BY pm.year_of_study, e.semester, m.module_name
");
$records_stmt->execute($params);
$all_records = $records_stmt->fetchAll(PDO::FETCH_ASSOC);

$grouped_records = [];
foreach ($all_records as $record) {
    $year_of_study = $record['year_of_study'] ?? 'Other/Elective';
    $key = "Year " . $year_of_study . " - Semester " . $record['semester'];
    $grouped_records[$key][] = $record;
}
ksort($grouped_records);


// --- PDF GENERATION ---
class PDF extends FPDF {
    function Header() {
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, 'Sol Plaatje University', 0, 1, 'C');
        $this->Ln(5);
    }
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();

// --- THE FIX IS ALSO HERE ---
// Combine 'first_name' and 'last_name' for the PDF output.
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 7, "Student: " . $student['first_name'] . ' ' . $student['last_name'], 0, 1);
$pdf->Cell(0, 7, "Address: " . ($student['home_address'] ?? 'N/A'), 0, 1);
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, $transcript_title, 0, 1, 'C');
$pdf->Ln(5);

if (count($grouped_records) > 0) {
    foreach($grouped_records as $heading => $group) {
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, $heading, 0, 1);
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(150, 8, 'Module Name', 1);
        $pdf->Cell(40, 8, 'Mark/Grade', 1, 1, 'C');
        $pdf->SetFont('Arial', '', 11);
        foreach($group as $record) {
            $pdf->Cell(150, 8, $record['module_name'], 1);
            $grade = $record['grade'] ? number_format($record['grade'], 2) . '%' : 'In Progress';
            $pdf->Cell(40, 8, $grade, 1, 1, 'C');
        }
        $pdf->Ln(10);
    }
} else {
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'No academic records found for the selected period.', 0, 1);
}

$pdf->Output('D', 'Academic_Transcript.pdf');