<?php
// student_tracking.php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$page_title = 'Study Progress Tracking';
require_once __DIR__ . '/../includes/header.php';
require_role('student');

$student_user_id = $_SESSION['user_id'];

// Function to calculate required hours based on module credits
function calculateRequiredHours($credits) {
    $creditHoursMap = [
        8 => 10,
        10 => 12,
        15 => 14,
        16 => 15,
        20 => 18,
        24 => 21,
        25 => 23
    ];
    
    return isset($creditHoursMap[$credits]) ? $creditHoursMap[$credits] : 0;
}

// Fetch ALL enrolled modules for the student (removed the grade IS NULL condition)
$stmt_modules = $pdo->prepare("
    SELECT m.module_id, m.module_code, m.module_name, m.credits
    FROM enrollments e
    JOIN modules m ON e.module_id = m.module_id
    WHERE e.student_user_id = :user_id
    ORDER BY m.module_code
");
$stmt_modules->execute(['user_id' => $student_user_id]);
$modules = $stmt_modules->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $module_id = $_POST['module_id'];
    $hours_studied = floatval($_POST['hours_studied']);
    $current_topic = $_POST['current_topic'];
    $is_completed = isset($_POST['is_completed']) ? 1 : 0;
    
    // Calculate required hours for this module
    $stmt_credits = $pdo->prepare("SELECT credits FROM modules WHERE module_id = :module_id");
    $stmt_credits->execute(['module_id' => $module_id]);
    $module = $stmt_credits->fetch(PDO::FETCH_ASSOC);
    
    $required_hours = calculateRequiredHours($module['credits']);
    
    // Calculate hours per topic (simple distribution)
    $hours_per_topic = $required_hours > 0 ? $required_hours / 10 : 0; // Assuming 10 topics per module
    
    // Insert or update study progress
    $stmt = $pdo->prepare("
        INSERT INTO study_progress (student_user_id, module_id, hours_studied, current_topic, is_completed, required_hours, hours_per_topic, updated_at)
        VALUES (:student_user_id, :module_id, :hours_studied, :current_topic, :is_completed, :required_hours, :hours_per_topic, NOW())
        ON DUPLICATE KEY UPDATE 
        hours_studied = hours_studied + VALUES(hours_studied),
        current_topic = VALUES(current_topic),
        is_completed = VALUES(is_completed),
        updated_at = NOW()
    ");
    
    $stmt->execute([
        'student_user_id' => $student_user_id,
        'module_id' => $module_id,
        'hours_studied' => $hours_studied,
        'current_topic' => $current_topic,
        'is_completed' => $is_completed,
        'required_hours' => $required_hours,
        'hours_per_topic' => $hours_per_topic
    ]);
    
    $_SESSION['success_message'] = 'Study progress updated successfully!';
    header('Location: student_tracking.php');
    exit;
}

// Fetch current study progress
$stmt_progress = $pdo->prepare("
    SELECT sp.*, m.module_code, m.module_name, m.credits
    FROM study_progress sp
    JOIN modules m ON sp.module_id = m.module_id
    WHERE sp.student_user_id = :user_id
    ORDER BY m.module_code
");
$stmt_progress->execute(['user_id' => $student_user_id]);
$progress = $stmt_progress->fetchAll(PDO::FETCH_ASSOC);
?>

<section class="dashboard-section">
    <h2>Study Progress Tracking</h2>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success"><?php echo e($_SESSION['success_message']); unset($_SESSION['success_message']); ?></div>
    <?php endif; ?>
    
    <div class="study-tracking-container">
        <div class="tracking-form">
            <div class="form-header">
                <h3>Update Study Progress</h3>
                <div class="completion-checkbox">
                    <label class="checkbox-label">
                        <input type="checkbox" name="is_completed" id="is_completed" value="1">
                        Mark module as completed
                    </label>
                </div>
            </div>
            <form method="POST" action="student_tracking.php">
                <div class="form-group">
                    <label for="module_id">Select Module:</label>
                    <select name="module_id" id="module_id" required class="form-control">
                        <option value="">-- Select a module --</option>
                        <?php foreach ($modules as $module): ?>
                            <option value="<?php echo e($module['module_id']); ?>" 
                                    data-credits="<?php echo e($module['credits']); ?>">
                                <?php echo e($module['module_code'] . ' - ' . $module['module_name'] . ' (' . $module['credits'] . ' credits)'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="hours_studied">Hours Studied:</label>
                    <input type="number" name="hours_studied" id="hours_studied" step="0.5" min="0" required class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="current_topic">Current Topic/Area of Study:</label>
                    <input type="text" name="current_topic" id="current_topic" required class="form-control" placeholder="e.g., Introduction to Programming, Calculus Basics, etc.">
                </div>
                
                <div class="required-hours-info" id="required-hours-info" style="display: none;">
                    <p><strong>Required hours for this module: <span id="required-hours-value">0</span></strong></p>
                </div>
                
                <button type="submit" class="btn btn-primary">Update Progress</button>
            </form>
        </div>
        
        <div class="progress-summary">
            <h3>Current Study Progress</h3>
            <?php if (count($progress) > 0): ?>
                <div class="progress-list">
                    <?php foreach ($progress as $item): ?>
                        <div class="progress-item">
                            <h4><?php echo e($item['module_code'] . ' - ' . $item['module_name']); ?></h4>
                            <p><strong>Credits:</strong> <?php echo e($item['credits']); ?></p>
                            <p><strong>Hours Studied:</strong> <?php echo e($item['hours_studied']); ?> / <?php echo e($item['required_hours']); ?></p>
                            <p><strong>Current Topic:</strong> <?php echo e($item['current_topic']); ?></p>
                            <p><strong>Hours per Topic:</strong> ~<?php echo e(round($item['hours_per_topic'], 1)); ?> hours</p>
                            <p><strong>Status:</strong> <?php echo e($item['is_completed'] ? 'Completed' : 'In Progress'); ?></p>
                            <div class="progress-bar">
                                <?php 
                                $percentage = $item['required_hours'] > 0 ? min(100, ($item['hours_studied'] / $item['required_hours']) * 100) : 0;
                                ?>
                                <div class="progress-fill" style="width: <?php echo e($percentage); ?>%"></div>
                            </div>
                            <p class="progress-percentage"><?php echo e(round($percentage, 1)); ?>% Complete</p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>No study progress recorded yet. Start tracking your study hours above!</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const moduleSelect = document.getElementById('module_id');
    const requiredHoursInfo = document.getElementById('required-hours-info');
    const requiredHoursValue = document.getElementById('required-hours-value');
    
    function calculateHoursFromCredits(credits) {
        const creditMap = {
            8: 10,
            10: 12,
            15: 14,
            16: 15,
            20: 18,
            24: 21,
            25: 23
        };
        return creditMap[credits] || 0;
    }
    
    moduleSelect.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        if (selectedOption.value) {
            const credits = parseInt(selectedOption.getAttribute('data-credits'));
            const requiredHours = calculateHoursFromCredits(credits);
            
            requiredHoursValue.textContent = requiredHours;
            requiredHoursInfo.style.display = 'block';
        } else {
            requiredHoursInfo.style.display = 'none';
        }
    });
});
</script>

<style>
.study-tracking-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
    margin-top: 20px;
}

.tracking-form, .progress-summary {
    background: #f9f9f9;
    padding: 20px;
    border-radius: 8px;
    border: 1px solid #ddd;
}

.form-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 1px solid #e0e0e0;
}

.form-header h3 {
    margin: 0;
    color: #333;
}

.completion-checkbox {
    margin: 0;
}

.checkbox-label {
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: normal;
    margin: 0;
    white-space: nowrap;
}

.form-group {
    margin-bottom: 15px;
}

.form-control {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
}

.progress-item {
    background: white;
    padding: 15px;
    margin-bottom: 15px;
    border-radius: 6px;
    border-left: 4px solid #007bff;
}

.progress-bar {
    background: #e9ecef;
    border-radius: 4px;
    height: 8px;
    margin: 10px 0;
    overflow: hidden;
}

.progress-fill {
    background: #28a745;
    height: 100%;
    transition: width 0.3s ease;
}

.progress-percentage {
    font-size: 12px;
    color: #666;
    text-align: right;
    margin: 0;
}

.btn-primary {
    background: #007bff;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
    width: 100%;
    font-size: 16px;
}

.btn-primary:hover {
    background: #0056b3;
}

.alert-success {
    background: #d4edda;
    color: #155724;
    padding: 12px;
    border-radius: 4px;
    margin-bottom: 20px;
    border: 1px solid #c3e6cb;
}

@media (max-width: 768px) {
    .study-tracking-container {
        grid-template-columns: 1fr;
    }
    
    .form-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }
    
    .completion-checkbox {
        align-self: flex-end;
    }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>