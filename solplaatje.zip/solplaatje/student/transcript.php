<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$page_title = 'Academic Transcript';
require_once __DIR__ . '/../includes/header.php';
require_role('student');

$student_user_id = $_SESSION['user_id'];

$year_filter = $_GET['year'] ?? 'all';
$semester_filter = $_GET['semester'] ?? 'all';

// --- THE FIX IS HERE ---
// This query now correctly fetches the 'first_name' and 'last_name' columns.
$student_details_stmt = $pdo->prepare("
    SELECT u.first_name, u.last_name, sc.home_address
    FROM users u
    LEFT JOIN student_contacts sc ON u.user_id = sc.student_user_id
    WHERE u.user_id = ?
");
$student_details_stmt->execute([$student_user_id]);
$student = $student_details_stmt->fetch(PDO::FETCH_ASSOC);

// The rest of the transcript logic is correct and remains the same.
$params = [$student_user_id];
$sql_where = "";
$transcript_title = "Full Academic Transcript";

if ($year_filter !== 'all') {
    if ($semester_filter !== 'all') {
        $sql_where = " AND pm.year_of_study = ? AND e.semester = ?";
        array_push($params, $year_filter, $semester_filter);
        $transcript_title = "Academic Transcript - Year $year_filter Semester $semester_filter";
    } else {
        $sql_where = " AND pm.year_of_study = ?";
        $params[] = $year_filter;
        $transcript_title = "Academic Transcript - Full Year $year_filter";
    }
}

$records_stmt = $pdo->prepare("
    SELECT m.module_name, e.grade, e.semester, pm.year_of_study 
    FROM enrollments e
    JOIN modules m ON e.module_id = m.module_id
    LEFT JOIN programme_modules pm ON e.module_id = pm.module_id
    WHERE e.student_user_id = ? {$sql_where}
    GROUP BY e.enrollment_id
    ORDER BY pm.year_of_study, e.semester, m.module_name
");
$records_stmt->execute($params);
$all_records = $records_stmt->fetchAll(PDO::FETCH_ASSOC);

$grouped_records = [];
foreach ($all_records as $record) {
    $year_of_study = $record['year_of_study'] ?? 'Other/Elective';
    $key = "Year " . $year_of_study . " - Semester " . $record['semester'];
    $grouped_records[$key][] = $record;
}
ksort($grouped_records);
?>

<div class="transcript-container">
    <div class="transcript-header">
        <h1>Sol Plaatje University</h1>
        <p>
            <!-- THE FIX IS ALSO HERE: Combine 'first_name' and 'last_name' for display. -->
            <strong>Student:</strong> <?php echo e($student['first_name'] . ' ' . $student['last_name']); ?><br>
            <strong>Address:</strong> <?php echo e($student['home_address'] ?? 'N/A'); ?>
        </p>
    </div>

    <div class="transcript-title">
        <h2><?php echo e($transcript_title); ?></h2>
    </div>

    <div class="transcript-body">
        <?php if (count($grouped_records) > 0): ?>
            <?php foreach($grouped_records as $heading => $group): ?>
                <h3><?php echo e($heading); ?></h3>
                <table class="transcript-table">
                    <thead>
                        <tr>
                            <th>Module Name</th>
                            <th>Mark/Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($group as $record): ?>
                        <tr>
                            <td><?php echo e($record['module_name']); ?></td>
                            <td><?php echo e($record['grade'] ? number_format($record['grade'], 2) . '%' : 'In Progress'); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No academic records found for the selected period.</p>
        <?php endif; ?>
    </div>

    <div class="transcript-actions">
        <a href="generate_pdf.php?year=<?php echo e($year_filter); ?>&semester=<?php echo e($semester_filter); ?>" class="button">Download as PDF</a>
        <a href="dashboard.php" class="button-secondary">Back to Dashboard</a>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>