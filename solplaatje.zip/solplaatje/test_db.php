<?php
require_once 'config.php'; // Attempt to connect to the database

echo "<div style='font-family: Arial, sans-serif; padding: 20px; border: 1px solid #4CAF50; background-color: #e8f5e9; color: #333;'>";
echo "<h2>Database Connection Test</h2>";

// If the script reaches this point without a 'die' message from config.php, the connection is successful.
if (isset($pdo)) {
    echo "<p style='color: #2e7d32;'><strong>Success!</strong> The application is connected to the database ('" . DB_NAME . "').</p>";
} else {
    echo "<p style='color: #c62828;'><strong>Failure!</strong> The application could not connect to the database. Please check your settings in `config.php`.</p>";
}
echo "</div>";
?>